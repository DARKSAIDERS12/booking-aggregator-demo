import { Request, Response } from 'express';
import { StationService } from '../services/stationService';

class StationController {
    private stationService: StationService;

    constructor() {
        this.stationService = new StationService();
        // Привязываем методы к экземпляру для сохранения контекста this
        this.getAllStations = this.getAllStations.bind(this);
        this.getStationsFrom = this.getStationsFrom.bind(this);
        this.getStationMappings = this.getStationMappings.bind(this);
        this.createStationMapping = this.createStationMapping.bind(this);
        this.getStationGroups = this.getStationGroups.bind(this);
        this.createStationGroup = this.createStationGroup.bind(this);
        this.updateStationGroup = this.updateStationGroup.bind(this);
    }

    // Получение всех станций
    async getAllStations(req: Request, res: Response) {
        try {
            console.log('StationController: получение всех станций');
            
            // Получаем данные из StationService
            const stations = await this.stationService.getAllStations();
            
            console.log(`StationController: возвращаю ${stations.length} станций из StationService`);
            
            res.json({
                success: true,
                data: stations
            });
        } catch (error) {
            console.error('StationController: ошибка получения станций:', error);
            res.status(500).json({
                success: false,
                message: 'Ошибка получения станций',
                error: error instanceof Error ? error.message : 'Неизвестная ошибка'
            });
        }
    }

    // Получение станций назначения из указанной станции отправления
    async getStationsFrom(req: Request, res: Response) {
        try {
            const { from } = req.query;
            console.log('StationController: получение станций назначения для станции:', from);

            if (!from) {
                return res.status(400).json({
                    success: false,
                    message: 'Необходимо указать параметр from'
                });
            }

            // Получаем данные из StationService
            const stations = await this.stationService.getStationsFrom(from as string);
            
            console.log(`StationController: возвращаю ${stations.length} станций назначения`);

            res.json({
                success: true,
                data: stations
            });
        } catch (error) {
            console.error('StationController: ошибка получения станций назначения:', error);
            res.status(500).json({
                success: false,
                message: 'Ошибка получения станций назначения',
                error: error instanceof Error ? error.message : 'Неизвестная ошибка'
            });
        }
    }

    // Получение сопоставлений станций
    async getStationMappings(req: Request, res: Response) {
        try {
            console.log('StationController: получение сопоставлений станций');
            
            const mappings = await this.stationService.getStationMappings();
            
            res.json({
                success: true,
                data: mappings
            });
        } catch (error) {
            console.error('StationController: ошибка получения сопоставлений станций:', error);
            res.status(500).json({
                success: false,
                message: 'Ошибка получения сопоставлений станций',
                error: error instanceof Error ? error.message : 'Неизвестная ошибка'
            });
        }
    }

    // Создание сопоставления станций
    async createStationMapping(req: Request, res: Response) {
        try {
            const mappingData = req.body;
            console.log('StationController: создание сопоставления станций:', mappingData);

            if (!mappingData.api1_station_id && !mappingData.api2_station_id) {
                return res.status(400).json({
                    success: false,
                    message: 'Необходимо указать хотя бы одну станцию'
                });
            }

            const mapping = await this.stationService.createStationMapping(mappingData);

            res.json({
                success: true,
                data: mapping,
                message: 'Сопоставление станций создано'
            });
        } catch (error) {
            console.error('StationController: ошибка создания сопоставления станций:', error);
            res.status(500).json({
                success: false,
                message: 'Ошибка создания сопоставления станций',
                error: error instanceof Error ? error.message : 'Неизвестная ошибка'
            });
        }
    }

    // Получение групп станций
    async getStationGroups(req: Request, res: Response) {
        try {
            console.log('StationController: получение групп станций');
            
            const groups = await this.stationService.getStationGroups();
            
            res.json({
                success: true,
                data: groups
            });
        } catch (error) {
            console.error('StationController: ошибка получения групп станций:', error);
            res.status(500).json({
                success: false,
                message: 'Ошибка получения групп станций',
                error: error instanceof Error ? error.message : 'Неизвестная ошибка'
            });
        }
    }

    // Создание группы станций
    async createStationGroup(req: Request, res: Response) {
        try {
            const { name, main_station_id, child_stations } = req.body;
            console.log('StationController: создание группы станций:', { name, main_station_id, child_stations });

            if (!name || !main_station_id || !child_stations || !Array.isArray(child_stations)) {
                return res.status(400).json({
                    success: false,
                    message: 'Необходимо указать name, main_station_id и child_stations (массив)'
                });
            }

            const group = await this.stationService.createStationGroup(name, main_station_id, child_stations);

            res.json({
                success: true,
                data: group,
                message: 'Группа станций создана'
            });
        } catch (error) {
            console.error('StationController: ошибка создания группы станций:', error);
            res.status(500).json({
                success: false,
                message: 'Ошибка создания группы станций',
                error: error instanceof Error ? error.message : 'Неизвестная ошибка'
            });
        }
    }

    // Обновление группы станций
    async updateStationGroup(req: Request, res: Response) {
        try {
            const { id } = req.params;
            const updateData = req.body;
            console.log('StationController: обновление группы станций:', id, updateData);

            if (!id) {
                return res.status(400).json({
                    success: false,
                    message: 'Необходимо указать ID группы'
                });
            }

            const group = await this.stationService.updateStationGroup(id, updateData);

            res.json({
                success: true,
                data: group,
                message: 'Группа станций обновлена'
            });
        } catch (error) {
            console.error('StationController: ошибка обновления группы станций:', error);
            res.status(500).json({
                success: false,
                message: 'Ошибка обновления группы станций',
                error: error instanceof Error ? error.message : 'Неизвестная ошибка'
            });
        }
    }
}

export const stationController = new StationController();
