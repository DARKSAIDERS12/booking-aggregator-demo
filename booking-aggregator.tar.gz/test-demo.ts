console.log('🧪 Тестовый файл создан в:', new Date().toISOString());
console.log('Если nodemon работает, вы увидите это сообщение');


